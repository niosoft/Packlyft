// swift-tools-version:5.8
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

struct Product {
    let product: PackageDescription.Product
    let targets: [PackageDescription.Target]
}

// MARK: Target Dependencies

// swiftformat:disable wrapArguments
extension PackageDescription.Target.Dependency {
    static let AccountSwitcherFeature: Target.Dependency = "AccountSwitcherFeature"
    static let AccountUpgradesFeature: Target.Dependency = "AccountUpgradesFeature"
    static let ActivityFeature: Target.Dependency = "ActivityFeature"
    static let AddFundsFeature: Target.Dependency = "AddFundsFeature"
    static let AddL2AccountFeature: Target.Dependency = "AddL2AccountFeature"
    static let AddressFeature: Target.Dependency = "AddressFeature"
    static let Amplitude: Target.Dependency = .product(name: "AmplitudeSwift", package: "Amplitude-Swift")
    static let AppDomain: Target.Dependency = "AppDomain"
    static let ArgentAnalytics: Target.Dependency = "ArgentAnalytics"
    static let ArgentCore: Target.Dependency = "ArgentCore"
    static let ArgentTestUtilities: Target.Dependency = "ArgentTestUtilities"
    static let ArgentUI: Target.Dependency = "ArgentUI"
    static let AssetsFeature: Target.Dependency = "AssetsFeature"
    static let AttributedText: Target.Dependency = "AttributedText"
    static let BackupFeature: Target.Dependency = "BackupFeature"
    static let BalancesService: Target.Dependency = "BalancesService"
    static let BigInt: Target.Dependency = "BigInt"
    static let BrowserFeature: Target.Dependency = "BrowserFeature"
    static let CardFeature: Target.Dependency = "CardFeature"
    static let CodableWrappers: Target.Dependency = "CodableWrappers"
    static let CommonMarkAttributedString: Target.Dependency = "CommonMarkAttributedString"
    static let ComposableArchitecture: Target.Dependency = .product(name: "ComposableArchitecture", package: "swift-composable-architecture")
    static let ConfettiSwiftUI: Target.Dependency = "ConfettiSwiftUI"
    static let ContactsFeature: Target.Dependency = "ContactsFeature"
    static let DataCompression: Target.Dependency = "DataCompression"
    static let DeployAccountFeature: Target.Dependency = "DeployAccountFeature"
    static let DesignSystem: Target.Dependency = "DesignSystem"
    static let DomainParser: Target.Dependency = .product(name: "DomainParser", package: "SwiftDomainParser")
    static let FaviconFinder: Target.Dependency = "FaviconFinder"
    static let FeeTokenSelectionFeature: Target.Dependency = "FeeTokenSelectionFeature"
    static let FiatOnRampFeature: Target.Dependency = "FiatOnRampFeature"
    static let GiftFeature: Target.Dependency = "GiftFeature"
    static let ImportKeyFeature: Target.Dependency = "ImportKeyFeature"
    static let InvestFeature: Target.Dependency = "InvestFeature"
    static let InviteFeature: Target.Dependency = "InviteFeature"
    static let Kingfisher: Target.Dependency = "Kingfisher"
    static let Lottie: Target.Dependency = .product(name: "Lottie", package: "lottie-ios")
    static let NFTFeature: Target.Dependency = "NFTFeature"
    static let NewsFeedFeature: Target.Dependency = "NewsFeedFeature"
    static let Nimble: Target.Dependency = "Nimble"
    static let NonEmpty: Target.Dependency = .product(name: "NonEmpty", package: "swift-nonempty")
    static let OnboardingFeature: Target.Dependency = "OnboardingFeature"
    static let PhoneNumberKit: Target.Dependency = "PhoneNumberKit"
    static let PnL: Target.Dependency = "PnL"
    static let PulseUI: Target.Dependency = .product(name: "PulseUI", package: "Pulse")
    static let QRCodeScannerFeature: Target.Dependency = "QRCodeScannerFeature"
    static let Quick: Target.Dependency = "Quick"
    static let RPCSupportFeature: Target.Dependency = "RPCSupportFeature"
    static let Ramp: Target.Dependency = .product(name: "Ramp", package: "ramp-sdk-ios")
    static let Reusable: Target.Dependency = "Reusable"
    static let Rive: Target.Dependency = .product(name: "RiveRuntime", package: "rive-ios")
    static let SelectAccountFeature: Target.Dependency = "SelectAccountFeature"
    static let SelectChainFeature: Target.Dependency = "SelectChainFeature"
    static let SendFeature: Target.Dependency = "SendFeature"
    static let SnapshotTesting: Target.Dependency = .product(name: "SnapshotTesting", package: "swift-snapshot-testing")
    static let SpokFeature: Target.Dependency = "SpokFeature"
    static let Starknet: Target.Dependency = .product(name: "Starknet", package: "starknet.swift")
    static let StarknetAccountFeature: Target.Dependency = "StarknetAccountFeature"
    static let StarknetCore: Target.Dependency = "StarknetCore"
    static let SwapFeature: Target.Dependency = "SwapFeature"
    static let SwiftUIPager: Target.Dependency = "SwiftUIPager"
    static let Tagged: Target.Dependency = .product(name: "Tagged", package: "swift-tagged")
    static let TokenDetailsFeature: Target.Dependency = "TokenDetailsFeature"
    static let TokenDiscoveryFeature: Target.Dependency = "TokenDiscoveryFeature"
    static let TokenFeature: Target.Dependency = "TokenFeature"
    static let TokensService: Target.Dependency = "TokensService"
    static let TransactionReviewFeature: Target.Dependency = "TransactionReviewFeature"
    static let TransferSelectionFeature: Target.Dependency = "TransferSelectionFeature"
    static let TutorialFeature: Target.Dependency = "TutorialFeature"
    static let TwoFactorVerificationFeature: Target.Dependency = "TwoFactorVerificationFeature"
    static let UserAuthenticationFeature: Target.Dependency = "UserAuthenticationFeature"
    static let Validated: Target.Dependency = .product(name: "Validated", package: "swift-validated")
    static let VaultAccountFeature: Target.Dependency = "VaultAccountFeature"
    static let VaultRecoveryFeature: Target.Dependency = "VaultRecoveryFeature"
    static let WalletConnect: Target.Dependency = .product(name: "WalletConnect", package: "WalletConnectSwiftV2")
    static let WalletConnectFeature: Target.Dependency = "WalletConnectFeature"
    static let WalletConnectRouter: Target.Dependency = .product(name: "WalletConnectRouter", package: "WalletConnectSwiftV2")
    static let ZKSync: Target.Dependency = .product(name: "ZKSync", package: "zksync-swift")
    static let ZKSyncV1AccountFeature: Target.Dependency = "ZKSyncV1AccountFeature"
    static let ZKSyncV1Core: Target.Dependency = "ZKSyncV1Core"
    static let ZKSyncV1InvestFeature: Target.Dependency = "ZKSyncV1InvestFeature"
    static let ZKSyncV2AccountFeature: Target.Dependency = "ZKSyncV2AccountFeature"
    static let ZKSyncV2Core: Target.Dependency = "ZKSyncV2Core"
    static let web3: Target.Dependency = "web3.swift"
    static let web3Zksync: Target.Dependency = .product(name: "web3-zksync.swift", package: "web3.swift")
}

// swiftformat:enable wrapArguments

// MARK: Package Dependencies
let dependencies: [PackageDescription.Package.Dependency] = [
    .package(url: "https://github.com/AliSoftware/Reusable", .upToNextMajor(from: "4.1.2")),
    .package(url: "https://github.com/Dashlane/SwiftDomainParser.git", .upToNextMajor(from: "1.1.0")),
    .package(url: "https://github.com/GottaGetSwifty/CodableWrappers.git", exact: "3.0.1"),
    .package(url: "https://github.com/Quick/Nimble.git", .upToNextMajor(from: "13.6.0")),
    .package(url: "https://github.com/Quick/Quick.git", .upToNextMajor(from: "7.6.2")),
    .package(url: "https://github.com/airbnb/lottie-ios.git", .upToNextMajor(from: "4.5.0")),
    .package(url: "https://github.com/fermoya/SwiftUIPager.git", exact: "2.5.0"),
    .package(url: "https://github.com/gonzalezreal/AttributedText", .upToNextMajor(from: "1.0.1")),
    .package(url: "https://github.com/marmelroy/PhoneNumberKit", .upToNextMajor(from: "4.0.0")),
    .package(url: "https://github.com/mattt/CommonMarkAttributedString", .upToNextMajor(from: "0.2.0")),
    .package(url: "https://github.com/mw99/DataCompression", from: "3.8.0"),
    .package(url: "https://github.com/onevcat/Kingfisher.git", exact: "8.1.0"),
    .package(url: "https://github.com/pointfreeco/swift-composable-architecture.git", .upToNextMajor(from: "1.15.1")),
    .package(url: "https://github.com/pointfreeco/swift-nonempty.git", .upToNextMajor(from: "0.5.0")),
    .package(url: "https://github.com/pointfreeco/swift-snapshot-testing.git", .upToNextMajor(from: "1.17.5")),
    .package(url: "https://github.com/pointfreeco/swift-tagged.git", .upToNextMajor(from: "0.10.0")),
    .package(url: "https://github.com/pointfreeco/swift-validated", .upToNextMajor(from: "0.2.1")),
    .package(url: "https://github.com/rive-app/rive-ios.git", exact: "6.2.0"),
    .package(url: "https://github.com/simibac/ConfettiSwiftUI.git", exact: "1.1.0"),
    .package(url: "https://github.com/will-lumley/FaviconFinder.git", from: "5.1.3"),
    .package(url: "https://github.com/amplitude/Amplitude-Swift.git", exact: "1.9.4"),
]

// MARK: Products
let products: [Product] = [
    .init(
        product: .library(name: "AccountSwitcherFeature", targets: ["AccountSwitcherFeature"]),
        targets: [
            .target(
                name: "AccountSwitcherFeature",
                dependencies: [
                    .AddL2AccountFeature,
                    .ArgentCore,
                    .DesignSystem,
                    .TutorialFeature,
                    .VaultAccountFeature,
                    .VaultRecoveryFeature,
                    .ZKSyncV1AccountFeature,
                    .ZKSyncV2AccountFeature,
                ],
                path: "AccountSwitcherFeature/Sources",
                resources: [
                    .process("Resources/Animations/switcher-logo.json")
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "AccountSwitcherFeatureTests",
                dependencies: [
                    .AccountSwitcherFeature
                ],
                path: "AccountSwitcherFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "AccountUpgradesFeature", targets: ["AccountUpgradesFeature"]),
        targets: [
            .target(
                name: "AccountUpgradesFeature",
                dependencies: [
                    .ArgentCore,
                    .DesignSystem,
                    .StarknetCore,
                    .ZKSyncV2Core,
                ],
                path: "AccountUpgradesFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "AccountUpgradesFeatureTests",
                dependencies: [
                    .AccountUpgradesFeature,
                    .Nimble,
                    .Quick,
                ],
                path: "AccountUpgradesFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "ActivityFeature", targets: ["ActivityFeature"]),
        targets: [
            .target(
                name: "ActivityFeature",
                dependencies: [
                    .AppDomain,
                    .DesignSystem,
                    .ZKSyncV1InvestFeature,
                    .NFTFeature,
                    .WalletConnectFeature,
                    .ZKSyncV1Core,
                ],
                path: "ActivityFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "AddFundsFeature", targets: ["AddFundsFeature"]),
        targets: [
            .target(
                name: "AddFundsFeature",
                dependencies: [
                    .AddressFeature,
                    .AppDomain,
                    .DesignSystem,
                    .FiatOnRampFeature,
                    .TutorialFeature,
                ],
                path: "AddFundsFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "AddFundsFeatureTests",
                dependencies: [
                    .AddFundsFeature,
                    .Nimble,
                    .Quick,
                ],
                path: "AddFundsFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "AddL2AccountFeature", targets: ["AddL2AccountFeature"]),
        targets: [
            .target(
                name: "AddL2AccountFeature",
                dependencies: [
                    .DesignSystem,
                    .BackupFeature,
                    .TutorialFeature,
                ],
                path: "AddL2AccountFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "AddL2AccountFeatureTests",
                dependencies: [
                    .AddL2AccountFeature,
                ],
                path: "AddL2AccountFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "AddressFeature", targets: ["AddressFeature"]),
        targets: [
            .target(
                name: "AddressFeature",
                dependencies: [
                    .DesignSystem
                ],
                path: "AddressFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "AddressFeatureTests",
                dependencies: [
                    .AddressFeature
                ],
                path: "AddressFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "AppDomain", targets: ["AppDomain"]),
        targets: [
            .target(
                name: "AppDomain",
                dependencies: [
                    .ArgentCore,
                    .StarknetCore,
                    .AccountUpgradesFeature
                ],
                path: "AppDomain/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "AppDomainTests",
                dependencies: [
                    .AppDomain,
                    .Nimble,
                    .Quick
                ],
                path: "AppDomain/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "ArgentAnalytics", targets: ["ArgentAnalytics"]),
        targets: [
            .target(
                name: "ArgentAnalytics",
                dependencies: [
                    .Amplitude,
                    .ArgentCore,
                    .ComposableArchitecture
                ],
                path: "ArgentAnalytics/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "ArgentCore", targets: ["ArgentCore"]),
        targets: [
            .target(
                name: "ArgentCore",
                dependencies: [
                    .BigInt,
                    .CodableWrappers,
                    .ComposableArchitecture,
                    .DomainParser,
                    .NonEmpty,
                    .PulseUI,
                    .Starknet,
                    .Tagged,
                    .Validated,
                    .web3,
                ],
                path: "ArgentCore/Sources",
                exclude: [
                    "Providers/EthProvider/EthVault/ABI/Networks"
                ],
                resources: [
                    .copy("Resources/HashEmoji.txt"),
                    .copy("Resources/svg_render.html"),
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "ArgentCoreTests",
                dependencies: [
                    .ArgentCore,
                    .ComposableArchitecture,
                    .Nimble,
                    .Quick,
                ],
                path: "ArgentCore/Tests",
                resources: [
                    .copy("../Sources/Resources/HashEmoji.txt"),
                    .copy("../Sources/Resources/svg_render.html"),
                    .copy("../Tests/Vectors/BIP32TestVectors.json"),
                    .copy("../Tests/Vectors/BIP39TestVectors.json"),
                    .copy("../Tests/Vectors/GrindKeyTestVectors.json"),
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "ArgentTestUtilities", targets: ["ArgentTestUtilities"]),
        targets: [
            .target(
                name: "ArgentTestUtilities",
                dependencies: [
                    .DesignSystem,
                    .Nimble,
                    .Quick,
                    .SnapshotTesting,

                ],
                path: "ArgentTestUtilities/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "ArgentUI", targets: ["ArgentUI"]),
        targets: [
            .target(
                name: "ArgentUI",
                dependencies: [
                    .ArgentCore,
                    .AttributedText,
                    .CommonMarkAttributedString,
                    .ComposableArchitecture,
                    .Kingfisher,
                    .Lottie,
                    .Reusable,
                    .Rive
                ],
                path: "ArgentUI/Sources",
                resources: [
                    .process("Resources/Animations/onboarding-spinner.json"),
                    .process("Resources/Animations/onboarding-success.json"),
                    .process("Resources/Animations/starknet-intro-browser.json"),
                    .process("Resources/Animations/starknet-intro-starknet.json"),
                    .process("Resources/Color.xcassets"),
                    .process("Resources/Fonts/Barlow-Bold.ttf"),
                    .process("Resources/Fonts/Barlow-Medium.ttf"),
                    .process("Resources/Fonts/Barlow-Regular.ttf"),
                    .process("Resources/Fonts/Barlow-SemiBold.ttf"),
                    .process("Resources/Fonts/Barlow.ttf"),
                    .process("Resources/Localization/en.lproj"),
                    .process("Resources/SharedIcon.xcassets"),
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "ArgentUITests",
                dependencies: [
                    .DesignSystem,
                    .ArgentTestUtilities,
                    .Nimble,
                    .Quick,
                ],
                path: "ArgentUI/Tests",
                resources: [
                    .process("../Sources/Resources/Color.xcassets"),
                    .process("../Sources/Resources/Fonts/Barlow-Bold.ttf"),
                    .process("../Sources/Resources/Fonts/Barlow-Medium.ttf"),
                    .process("../Sources/Resources/Fonts/Barlow-Regular.ttf"),
                    .process("../Sources/Resources/Fonts/Barlow-SemiBold.ttf"),
                    .process("../Sources/Resources/Fonts/Barlow.ttf"),
                    .process("../Sources/Resources/SharedIcon.xcassets"),
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "AssetsFeature", targets: ["AssetsFeature"]),
        targets: [
            .target(
                name: "AssetsFeature",
                dependencies: [
                    .ArgentCore,
                    .ArgentUI,
                    .AppDomain,
                    .BackupFeature,
                    .CardFeature,
                    .DesignSystem,
                    .NFTFeature,
                    .InvestFeature,
                    .SendFeature
                ],
                path: "AssetsFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "AssetsFeatureTests",
                dependencies: [
                    .AssetsFeature,
                    .Nimble,
                    .Quick,
                ],
                path: "AssetsFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "BackupFeature", targets: ["BackupFeature"]),
        targets: [
            .target(
                name: "BackupFeature",
                dependencies: [
                    .DesignSystem,
                    .ArgentAnalytics,
                    .AppDomain,
                    .TutorialFeature
                ],
                path: "BackupFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "BackupFeatureTests",
                dependencies: [
                    .BackupFeature,
                    .Nimble,
                    .Quick,
                ],
                path: "BackupFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "BalancesService", targets: ["BalancesService"]),
        targets: [
            .target(
                name: "BalancesService",
                dependencies: [
                    .ArgentCore,
                    .TokensService
                ],
                path: "BalancesService/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "BalancesServiceTests",
                dependencies: [
                    .ArgentCore,
                    .BalancesService,
                    .Nimble,
                    .Quick,
                    .TokensService
                ],
                path: "BalancesService/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "BrowserFeature", targets: ["BrowserFeature"]),
        targets: [
            .target(
                name: "BrowserFeature",
                dependencies: [
                    .ArgentCore,
                    .DesignSystem,
                    .AppDomain,
                    .DataCompression,
                    .FaviconFinder,
                    .SelectAccountFeature,
                    .SpokFeature,
                    .StarknetCore,
                    .WalletConnect,
                    .WalletConnectFeature,
                ],
                path: "BrowserFeature/Sources",
                resources: [
                    .process("Resources/StarknetBridgeSetup.js"),
                    .process("Resources/StarknetMobileBridge.js.gz"),
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "BrowserFeatureTests",
                dependencies: [
                    .BrowserFeature
                ],
                path: "BrowserFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "CardFeature", targets: ["CardFeature"]),
        targets: [
            .target(
                name: "CardFeature",
                dependencies: [
                    .ArgentCore,
                    .ArgentUI,
                    .AppDomain,
                    .DesignSystem,
                    .StarknetCore,
                    .TutorialFeature,
                    .TwoFactorVerificationFeature
                ],
                path: "CardFeature/Sources",
                resources: [
                    .process("Resources/Assets.xcassets"),
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "CardFeatureTests",
                dependencies: [
                    .CardFeature,
                    .Nimble,
                    .Quick,
                ],
                path: "CardFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "ContactsFeature", targets: ["ContactsFeature"]),
        targets: [
            .target(
                name: "ContactsFeature",
                dependencies: [
                    .AddressFeature,
                    .AppDomain,
                    .DesignSystem,
                    .QRCodeScannerFeature,
                    .SelectAccountFeature,
                    .SelectChainFeature,
                ],
                path: "ContactsFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "ContactsFeatureTests",
                dependencies: [
                    .DesignSystem,
                    .ContactsFeature,
                    .Nimble,
                    .Quick
                ],
                path: "ContactsFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "DeployAccountFeature", targets: ["DeployAccountFeature"]),
        targets: [
            .target(
                name: "DeployAccountFeature",
                dependencies: [
                    .DesignSystem,
                    .StarknetCore
                ],
                path: "DeployAccountFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "DeployAccountFeatureTests",
                dependencies: [
                    .DeployAccountFeature
                ],
                path: "DeployAccountFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "DesignSystem", targets: ["DesignSystem"]),
        targets: [
            .target(
                name: "DesignSystem",
                dependencies: [
                    .ArgentUI
                ],
                path: "DesignSystem/Sources",
                resources: [
                    .process("Resources/Icon.xcassets"),
                    .process("Resources/Illustration.xcassets"),
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "DesignSystemTests",
                dependencies: [
                    .DesignSystem,
                    .ArgentTestUtilities,
                    .Nimble,
                    .Quick,
                ],
                path: "DesignSystem/Tests",
                resources: [
                    .process("Resources/eth-logo.png"),
                    .process("Resources/nostra-logo.png"),
                    .process("Resources/strk-logo.png"),
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "FeeTokenSelectionFeature", targets: ["FeeTokenSelectionFeature"]),
        targets: [
            .target(
                name: "FeeTokenSelectionFeature",
                dependencies: [
                    .DesignSystem
                ],
                path: "FeeTokenSelectionFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "FeeTokenSelectionFeatureTests",
                dependencies: [
                    .FeeTokenSelectionFeature,
                    .Nimble,
                    .Quick,
                ],
                path: "FeeTokenSelectionFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "FiatOnRampFeature", targets: ["FiatOnRampFeature"]),
        targets: [
            .target(
                name: "FiatOnRampFeature",
                dependencies: [
                    .AppDomain,
                    .ArgentAnalytics,
                    .ArgentCore,
                    .DesignSystem,
                    .Ramp,
                ],
                path: "FiatOnRampFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "FiatOnRampFeatureTests",
                dependencies: [
                    .FiatOnRampFeature,
                    .Nimble,
                    .Quick,
                ],
                path: "FiatOnRampFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "GiftFeature", targets: ["GiftFeature"]),
        targets: [
            .target(
                name: "GiftFeature",
                dependencies: [
                    .DesignSystem,
                    .ConfettiSwiftUI,
                    .SwiftUIPager,
                    .ZKSyncV1Core,
                ],
                path: "GiftFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "GiftFeatureTests",
                dependencies: [
                    .GiftFeature
                ],
                path: "GiftFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "ImportKeyFeature", targets: ["ImportKeyFeature"]),
        targets: [
            .target(
                name: "ImportKeyFeature",
                dependencies: [
                    .ArgentAnalytics,
                    .ArgentCore,
                    .DesignSystem,
                    .QRCodeScannerFeature,
                    .StarknetCore,
                    .TutorialFeature,
                    .UserAuthenticationFeature,
                ],
                path: "ImportKeyFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "ImportKeyFeatureTests",
                dependencies: [
                    .ImportKeyFeature
                ],
                path: "ImportKeyFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "ZKSyncV1InvestFeature", targets: ["ZKSyncV1InvestFeature"]),
        targets: [
            // Targets are the basic building blocks of a package. A target can define a module or a test suite.
            // Targets can depend on other targets in this package, and on products in packages this package depends on.
            .target(
                name: "ZKSyncV1InvestFeature",
                dependencies: [
                    .ArgentCore,
                    .DesignSystem,
                    .FiatOnRampFeature,
                ],
                path: "ZKSyncV1InvestFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "ZKSyncV1InvestFeatureTests",
                dependencies: [
                    .ZKSyncV1InvestFeature,
                    .Nimble,
                    .Quick,
                ],
                path: "ZKSyncV1InvestFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "InvestFeature", targets: ["InvestFeature"]),
        targets: [
            .target(
                name: "InvestFeature",
                dependencies: [
                    .AppDomain,
                    .ArgentCore,
                    .DesignSystem,
                    .TransactionReviewFeature,
                    .StarknetCore,
                    .SendFeature,
                ],
                path: "InvestFeature/Sources",
                resources: [
                    .process("Resources/Assets.xcassets")
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "InvestFeatureTests",
                dependencies: [
                    .InvestFeature,
                    .Nimble,
                    .Quick,
                ],
                path: "InvestFeature/Tests",
                resources: [
                    .copy("Fixtures/account_a.json"),
                    .copy("Fixtures/account_b.json"),
                    .copy("Fixtures/account_c.json")
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "InviteFeature", targets: ["InviteFeature"]),
        targets: [
            .target(
                name: "InviteFeature",
                dependencies: [
                    .DesignSystem
                ],
                path: "InviteFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "NewsFeedFeature", targets: ["NewsFeedFeature"]),
        targets: [
            .target(
                name: "NewsFeedFeature",
                dependencies: [
                    .AppDomain,
                    .ArgentCore,
                    .DesignSystem,
                ],
                path: "NewsFeedFeature/Sources"
            )
        ]
    ),
    .init(
        product: .library(name: "NFTFeature", targets: ["NFTFeature"]),
        targets: [
            .target(
                name: "NFTFeature",
                dependencies: [
                    .DesignSystem
                ],
                path: "NFTFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "OnboardingFeature", targets: ["OnboardingFeature"]),
        targets: [
            .target(
                name: "OnboardingFeature",
                dependencies: [
                    .DesignSystem,
                    .BackupFeature,
                    .TwoFactorVerificationFeature,
                    .VaultAccountFeature,
                    .ZKSyncV1Core,
                    .ZKSyncV2Core,
                ],
                path: "OnboardingFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "OnboardingFeatureTests",
                dependencies: [
                    .OnboardingFeature
                ],
                path: "OnboardingFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "PnL", targets: ["PnL"]),
        targets: [
            .target(
                name: "PnL",
                dependencies: [
                    .ArgentCore,
                    .ComposableArchitecture
                ],
                path: "PnL/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "QRCodeScannerFeature", targets: ["QRCodeScannerFeature"]),
        targets: [
            .target(
                name: "QRCodeScannerFeature",
                dependencies: [
                    .DesignSystem,
                    .SelectChainFeature,
                    .WalletConnect,

                ],
                path: "QRCodeScannerFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "QRCodeScannerFeatureTests",
                dependencies: [
                    .DesignSystem,
                    .Nimble,
                    .QRCodeScannerFeature,
                    .Quick,
                ],
                path: "QRCodeScannerFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "RPCSupportFeature", targets: ["RPCSupportFeature"]),
        targets: [
            .target(
                name: "RPCSupportFeature",
                dependencies: [
                    .ArgentAnalytics,
                    .ArgentCore,
                    .AppDomain,
                    .DesignSystem,
                    .ComposableArchitecture,
                ],
                path: "RPCSupportFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "RPCSupportFeatureTests",
                dependencies: [
                    .RPCSupportFeature
                ],
                path: "RPCSupportFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "SelectAccountFeature", targets: ["SelectAccountFeature"]),
        targets: [
            .target(
                name: "SelectAccountFeature",
                dependencies: [
                    .AppDomain,
                    .DesignSystem
                ],
                path: "SelectAccountFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "SelectAccountFeatureTests",
                dependencies: [
                    .Nimble,
                    .Quick,
                    .SelectAccountFeature,
                ],
                path: "SelectAccountFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "SelectChainFeature", targets: ["SelectChainFeature"]),
        targets: [
            .target(
                name: "SelectChainFeature",
                dependencies: [
                    .DesignSystem
                ],
                path: "SelectChainFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "SelectChainFeatureTests",
                dependencies: [
                    .Nimble,
                    .Quick,
                    .SelectChainFeature,
                ],
                path: "SelectChainFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "SendFeature", targets: ["SendFeature"]),
        targets: [
            .target(
                name: "SendFeature",
                dependencies: [
                    .ActivityFeature,
                    .DesignSystem,
                    .ContactsFeature,
                    .GiftFeature,
                    .InviteFeature,
                    .NFTFeature,
                    .QRCodeScannerFeature,
                    .StarknetCore,
                    .TutorialFeature,
                    .ZKSyncV1Core,
                    .ZKSyncV2Core,
                ],
                path: "SendFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "SendFeatureTests",
                dependencies: [
                    .SendFeature
                ],
                path: "SendFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "SpokFeature", targets: ["SpokFeature"]),
        targets: [
            .target(
                name: "SpokFeature",
                dependencies: [
                    .ArgentCore,
                    .DesignSystem,
                    .QRCodeScannerFeature,
                    .StarknetCore,
                    .TutorialFeature,
                    .WalletConnectFeature,
                ],
                path: "SpokFeature/Sources",
                resources: [
                    .process("Resources/Animations/claim-confetti.json"),
                    .process("Resources/Animations/claim-failed.json"),
                    .process("Resources/Animations/claim-ineligible.json"),
                    .process("Resources/Animations/claim-loading.json"),
                    .process("Resources/Animations/spok-intro.json"),
                    .process("Resources/Animations/spoker-body.riv"),
                    .process("Resources/Animations/spoker-feet.riv"),
                    .process("Resources/Animations/spoker-plus-dark.riv"),
                    .process("Resources/Animations/spoker-plus.riv"),
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "SpokFeatureTests",
                dependencies: [
                    .Nimble,
                    .Quick,
                    .SpokFeature,
                ],
                path: "SpokFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "StarknetAccountFeature", targets: ["StarknetAccountFeature"]),
        targets: [
            .target(
                name: "StarknetAccountFeature",
                dependencies: [
                    .AccountUpgradesFeature,
                    .ActivityFeature,
                    .AddFundsFeature,
                    .AppDomain,
                    .ArgentCore,
                    .AssetsFeature,
                    .BackupFeature,
                    .BalancesService,
                    .BrowserFeature,
                    .CardFeature,
                    .DeployAccountFeature,
                    .DesignSystem,
                    .GiftFeature,
                    .ImportKeyFeature,
                    .InvestFeature,
                    .NewsFeedFeature,
                    .NFTFeature,
                    .PnL,
                    .SendFeature,
                    .StarknetCore,
                    .SwapFeature,
                    .TokenDetailsFeature,
                    .TokenFeature,
                    .TokensService,
                    .TransferSelectionFeature,
                    .ZKSyncV1Core,
                    .ZKSyncV2Core,
                ],
                path: "StarknetAccountFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "StarknetAccountFeatureTests",
                dependencies: [
                    .StarknetAccountFeature,
                    .VaultAccountFeature
                ],
                path: "StarknetAccountFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "StarknetCore", targets: ["StarknetCore"]),
        targets: [
            .target(
                name: "StarknetCore",
                dependencies: [
                    .ArgentCore,
                    .ArgentAnalytics,
                    .NFTFeature,
                    .Starknet,
                ],
                path: "StarknetCore/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "StarknetCoreTests",
                dependencies: [
                    .Nimble,
                    .Quick,
                    .StarknetCore,
                ],
                path: "StarknetCore/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "SwapFeature", targets: ["SwapFeature"]),
        targets: [
            .target(
                name: "SwapFeature",
                dependencies: [
                    .AppDomain,
                    .ArgentCore,
                    .DesignSystem,
                    .Starknet,
                    .StarknetCore,
                    .TokenDiscoveryFeature,
                    .FeeTokenSelectionFeature
                ],
                path: "SwapFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "SwapFeatureTests",
                dependencies: [
                    .ArgentTestUtilities,
                    .SwapFeature
                ],
                path: "SwapFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "TokenDetailsFeature", targets: ["TokenDetailsFeature"]),
        targets: [
            .target(
                name: "TokenDetailsFeature",
                dependencies: [
                    .ActivityFeature,
                    .DesignSystem,
                    .BackupFeature,
                    .PnL,
                ],
                path: "TokenDetailsFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "TokenDetailsFeatureTests",
                dependencies: [
                    .ArgentTestUtilities,
                    .TokenDetailsFeature,
                ],
                path: "TokenDetailsFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "TokenDiscoveryFeature", targets: ["TokenDiscoveryFeature"]),
        targets: [
            .target(
                name: "TokenDiscoveryFeature",
                dependencies: [
                    .DesignSystem
                ],
                path: "TokenDiscoveryFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "TokenDiscoveryFeatureTests",
                dependencies: [
                    .TokenDiscoveryFeature
                ],
                path: "TokenDiscoveryFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "TokenFeature", targets: ["TokenFeature"]),
        targets: [
            .target(
                name: "TokenFeature",
                dependencies: [
                    .ActivityFeature,
                    .AddFundsFeature,
                    .ArgentCore,
                    .DesignSystem,
                    .SendFeature,
                    .TokenDetailsFeature,
                ],
                path: "TokenFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "TokenFeatureTests",
                dependencies: [
                    .TokenFeature
                ],
                path: "TokenFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "TokensService", targets: ["TokensService"]),
        targets: [
            .target(
                name: "TokensService",
                dependencies: [
                    .ArgentCore
                ],
                path: "TokensService/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "TransactionReviewFeature", targets: ["TransactionReviewFeature"]),
        targets: [
            .target(
                name: "TransactionReviewFeature",
                dependencies: [
                    .AppDomain,
                    .ArgentCore,
                    .DesignSystem,
                    .NFTFeature,
                    .Starknet,
                    .StarknetCore,
                    .FeeTokenSelectionFeature
                ],
                path: "TransactionReviewFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "TransactionReviewFeatureTests",
                dependencies: [
                    .ArgentTestUtilities,
                    .Nimble,
                    .Quick,
                    .TransactionReviewFeature,
                ],
                path: "TransactionReviewFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "TransferSelectionFeature", targets: ["TransferSelectionFeature"]),
        targets: [
            .target(
                name: "TransferSelectionFeature",
                dependencies: [
                    .AddFundsFeature,
                    .ArgentCore,
                    .DesignSystem,
                    .BackupFeature,
                    .SendFeature,
                ],
                path: "TransferSelectionFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "TransferSelectionFeatureTests",
                dependencies: [
                    .TransferSelectionFeature
                ],
                path: "TransferSelectionFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "TutorialFeature", targets: ["TutorialFeature"]),
        targets: [
            .target(
                name: "TutorialFeature",
                dependencies: [
                    .DesignSystem
                ],
                path: "TutorialFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "TutorialFeatureTests",
                dependencies: [
                    .TutorialFeature
                ],
                path: "TutorialFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "TwoFactorVerificationFeature", targets: ["TwoFactorVerificationFeature"]),
        targets: [
            .target(
                name: "TwoFactorVerificationFeature",
                dependencies: [
                    .AppDomain,
                    .DesignSystem,
                    .PhoneNumberKit,
                ],
                path: "TwoFactorVerificationFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "TwoFactorVerificationFeatureTests",
                dependencies: [
                    .Nimble,
                    .Quick,
                    .TwoFactorVerificationFeature,
                ],
                path: "TwoFactorVerificationFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "UserAuthenticationFeature", targets: ["UserAuthenticationFeature"]),
        targets: [
            .target(
                name: "UserAuthenticationFeature",
                dependencies: [
                    .DesignSystem
                ],
                path: "UserAuthenticationFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "UserAuthenticationFeatureTests",
                dependencies: [
                    .UserAuthenticationFeature
                ],
                path: "UserAuthenticationFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "VaultAccountFeature", targets: ["VaultAccountFeature"]),
        targets: [
            .target(
                name: "VaultAccountFeature",
                dependencies: [
                    .AppDomain,
                    .ArgentAnalytics,
                    .ArgentCore,
                    .DesignSystem,
                    .ContactsFeature,
                    .FiatOnRampFeature,
                    .InviteFeature,
                    .NFTFeature,
                    .PhoneNumberKit,
                    .QRCodeScannerFeature,
                    .StarknetAccountFeature,
                    .TutorialFeature,
                    .WalletConnectFeature,
                    .ZKSyncV1Core,
                ],
                path: "VaultAccountFeature/Sources",
                exclude: [
                    "Providers/Ethereum/ABI/Networks"
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "VaultAccountFeatureTests",
                dependencies: [
                    .ArgentTestUtilities,
                    .VaultAccountFeature,
                ],
                path: "VaultAccountFeature/Tests",
                resources: [
                    .copy("Data/LocalData.json")
                ],
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "VaultRecoveryFeature", targets: ["VaultRecoveryFeature"]),
        targets: [
            .target(
                name: "VaultRecoveryFeature",
                dependencies: [
                    .AppDomain,
                    .ArgentCore,
                    .DesignSystem,
                    .OnboardingFeature,
                    .UserAuthenticationFeature
                ],
                path: "VaultRecoveryFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "VaultRecoveryFeatureTests",
                dependencies: [
                    .ArgentTestUtilities,
                    .VaultRecoveryFeature,
                ],
                path: "VaultRecoveryFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "WalletConnectFeature", targets: ["WalletConnectFeature"]),
        targets: [
            .target(
                name: "WalletConnectFeature",
                dependencies: [
                    .AppDomain,
                    .ArgentAnalytics,
                    .DesignSystem,
                    .FeeTokenSelectionFeature,
                    .NFTFeature,
                    .SelectAccountFeature,
                    .StarknetCore,
                    .TransactionReviewFeature,
                    .WalletConnect,
                    .WalletConnectRouter,
                    .ZKSyncV1Core,
                    .ZKSyncV2Core,
                ],
                path: "WalletConnectFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "WalletConnectFeatureTests",
                dependencies: [
                    .Nimble,
                    .Quick,
                    .WalletConnectFeature,
                ],
                path: "WalletConnectFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            )
        ]
    ),
    .init(
        product: .library(name: "ZKSyncV1AccountFeature", targets: ["ZKSyncV1AccountFeature"]),
        targets: [
            .target(
                name: "ZKSyncV1AccountFeature",
                dependencies: [
                    .ActivityFeature,
                    .AddFundsFeature,
                    .AppDomain,
                    .ArgentAnalytics,
                    .ArgentCore,
                    .DesignSystem,
                    .BackupFeature,
                    .FiatOnRampFeature,
                    .GiftFeature,
                    .InviteFeature,
                    .PnL,
                    .SendFeature,
                    .TokenDetailsFeature,
                    .TokenDiscoveryFeature,
                    .TransferSelectionFeature,
                    .TutorialFeature,
                    .WalletConnectFeature,
                    .ZKSyncV1Core,
                ],
                path: "ZKSyncV1AccountFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "ZKSyncV1AccountFeatureTests",
                dependencies: [
                    .ArgentTestUtilities,
                    .ZKSyncV1AccountFeature,
                ],
                path: "ZKSyncV1AccountFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "ZKSyncV1Core", targets: ["ZKSyncV1Core"]),
        targets: [
            // Targets are the basic building blocks of a package. A target can define a module or a test suite.
            // Targets can depend on other targets in this package, and on products in packages this package depends on.
            .target(
                name: "ZKSyncV1Core",
                dependencies: [
                    .ArgentCore,
                    .ZKSync
                ],
                path: "ZKSyncV1Core/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "ZKSyncV1CoreTests",
                dependencies: [
                    .Nimble,
                    .Quick,
                    .ZKSyncV1Core,
                ],
                path: "ZKSyncV1Core/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "ZKSyncV2AccountFeature", targets: ["ZKSyncV2AccountFeature"]),
        targets: [
            .target(
                name: "ZKSyncV2AccountFeature",
                dependencies: [
                    .ActivityFeature,
                    .AddFundsFeature,
                    .AppDomain,
                    .ArgentAnalytics,
                    .ArgentCore,
                    .DesignSystem,
                    .BackupFeature,
                    .FiatOnRampFeature,
                    .GiftFeature,
                    .InviteFeature,
                    .NFTFeature,
                    .PnL,
                    .SendFeature,
                    .TokenDetailsFeature,
                    .TokenDiscoveryFeature,
                    .TokenFeature,
                    .TransferSelectionFeature,
                    .VaultAccountFeature,
                    .WalletConnectFeature,
                    .ZKSyncV1Core,
                ],
                path: "ZKSyncV2AccountFeature/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "ZKSyncV2AccountFeatureTests",
                dependencies: [
                    .ZKSyncV2AccountFeature
                ],
                path: "ZKSyncV2AccountFeature/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
    .init(
        product: .library(name: "ZKSyncV2Core", targets: ["ZKSyncV2Core"]),
        targets: [
            .target(
                name: "ZKSyncV2Core",
                dependencies: [
                    .ArgentCore,
                    .web3Zksync,
                ],
                path: "ZKSyncV2Core/Sources",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
            .testTarget(
                name: "ZKSyncV2CoreTests",
                dependencies: [
                    .Nimble,
                    .Quick,
                    .ZKSyncV2Core,
                ],
                path: "ZKSyncV2Core/Tests",
                swiftSettings: [
                    // .concurrencyChecking
                ]
            ),
        ]
    ),
]

let package = Package(
    name: "PhotoGalleryModules",
    defaultLocalization: "en",
    platforms: [
        .iOS(SupportedPlatform.IOSVersion.v16)
    ],
    products: products.map(\.product),
    dependencies: dependencies,
    targets: products.flatMap(\.targets)
)

extension SwiftSetting {
    /// Enable complete concurrency checking for a target in a Swift package using Swift 5.9 or Swift 5.10
    /// [Swift Concurrency Documentation](https://www.swift.org/documentation/concurrency/)
    static var concurrencyChecking: SwiftSetting {
        .enableExperimentalFeature("StrictConcurrency")
    }
}
